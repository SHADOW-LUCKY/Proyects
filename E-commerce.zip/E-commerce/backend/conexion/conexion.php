<?php
require_once("db.php");
class Conexion{
    public static function conexion(){
        $conexion = new mysqli(DB_HOST, DB_USER, DB_PWD, DB_NAME);
        return $conexion;
    }
}
?>