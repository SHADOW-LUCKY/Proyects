<?php

class Canvas{
    public function draw()
    {
        include("views/template.php");   
    }
}
?>
