<?php
require_once("conexion/conexion.php");
class Productos extends Conexion{
    private $id;
    private $nombre;
    private $descripcion;
    private $precio;
    private $imagen;
    private $categoria;
    protected $dbCnx;

    /* Constructor */
    public function __construct($id=0, $nombre="", $descripcion="", $precio=0, $imagen="", $categoria=""){
        $this->id = $id;
        $this->nombre = $nombre;
        $this->descripcion = $descripcion;
        $this->precio = $precio;
        $this->imagen = $imagen;
        $this->categoria = $categoria;
        $this->dbCnx = parent::__construct($dbCnx);
    }
    /* getters */
    public function getId(){
        return $this->id;
    }
    public function getNombre(){
        return $this->nombre;
    }
    public function getDescripcion(){
        return $this->descripcion;
    }
    public function getPrecio(){
        return $this->precio;
    }
    public function getImagen(){
        return $this->imagen;
    }
    public function getCategoria(){
        return $this->categoria;
    }
    /* setters */
    public function setId($id){
        $this->id = $id;
    }
    public function setNombre($nombre){
        $this->nombre = $nombre;
    }
    public function setDescripcion($descripcion){
        $this->descripcion = $descripcion;
    }
    public function setPrecio($precio){
        $this->precio = $precio;
    }
    public function setImagen($imagen){
        $this->imagen = $imagen;
    }
    public function setCategoria($categoria){
        $this->categoria = $categoria;
    }
    /* Funciones */
    public function insertar(){
        $stat = $this->$dbCnx->prepare("INSERT INTO productos (nombre, descripcion, precio, imagen, categoria) VALUES ('?', '?', '?', '?', '?')");
        

    }
    
}
?>